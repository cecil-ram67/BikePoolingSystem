package com.ridemate.bikepoolingsystem.dto.ridejoin;

import com.ridemate.bikepoolingsystem.enumtype.RideJoinStatus;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public record RideJoinResponse(
        Long id,
        Long rideOfferId,
        Long passengerId,
        String passengerName,
        String origin,
        String destination,
        LocalDate travelDate,
        LocalTime departureTime,
        BigDecimal fareAmount,
        BigDecimal cancellationCharge,
        BigDecimal refundAmount,
        RideJoinStatus status,
        LocalDateTime createdAt,
        LocalDateTime updatedAt,
        LocalDateTime cancelledAt
) {
}
