package com.ridemate.bikepoolingsystem.enumtype;

public enum RideStatus {
    OPEN,
    FULL,
    COMPLETED,
    CANCELLED
}