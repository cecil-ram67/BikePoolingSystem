package com.ridemate.bikepoolingsystem.repository;

import com.ridemate.bikepoolingsystem.entity.RideJoin;
import com.ridemate.bikepoolingsystem.enumtype.RideJoinStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface RideJoinRepository extends JpaRepository<RideJoin, Long> {

    Optional<RideJoin> findByIdAndIsDeletedFalse(Long id);

    boolean existsByRideOfferIdAndPassengerIdAndIsDeletedFalseAndStatusIn(
            Long rideOfferId,
            Long passengerId,
            Collection<RideJoinStatus> statuses
    );

    List<RideJoin> findAllByPassengerIdAndIsDeletedFalse(Long passengerId);

    List<RideJoin> findAllByRideOfferIdAndIsDeletedFalse(Long rideOfferId);
}
