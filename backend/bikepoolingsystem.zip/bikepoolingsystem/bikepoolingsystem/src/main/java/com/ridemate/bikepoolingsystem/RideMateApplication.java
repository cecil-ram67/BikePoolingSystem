package com.ridemate.bikepoolingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RideMateApplication {

	public static void main(String[] args) {
		SpringApplication.run(RideMateApplication.class, args);
	}

}
