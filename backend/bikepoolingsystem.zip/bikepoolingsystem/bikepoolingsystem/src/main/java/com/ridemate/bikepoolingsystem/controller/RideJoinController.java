package com.ridemate.bikepoolingsystem.controller;

import com.ridemate.bikepoolingsystem.dto.ridejoin.RideJoinRequest;
import com.ridemate.bikepoolingsystem.dto.ridejoin.RideJoinResponse;
import com.ridemate.bikepoolingsystem.service.RideJoinService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ride-joins")
public class RideJoinController {

    private final RideJoinService rideJoinService;

    public RideJoinController(RideJoinService rideJoinService) {
        this.rideJoinService = rideJoinService;
    }

    // PASSENGER: request to join ride
    @PostMapping
    @PreAuthorize("hasRole('PASSENGER')")
    public ResponseEntity<RideJoinResponse> requestToJoin(
            @Valid @RequestBody RideJoinRequest request) {
        return ResponseEntity.ok(rideJoinService.requestToJoin(request));
    }

    // DRIVER: approve join
    @PostMapping("/{id}/approve")
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<RideJoinResponse> approveJoin(
            @PathVariable Long id,
            @RequestParam Long driverId) {
        return ResponseEntity.ok(rideJoinService.approveJoin(id, driverId));
    }

    // DRIVER: reject join
    @PostMapping("/{id}/reject")
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<RideJoinResponse> rejectJoin(
            @PathVariable Long id,
            @RequestParam Long driverId) {
        return ResponseEntity.ok(rideJoinService.rejectJoin(id, driverId));
    }

    // PASSENGER: cancel join
    @PostMapping("/{id}/cancel")
    @PreAuthorize("hasRole('PASSENGER')")
    public ResponseEntity<RideJoinResponse> cancelByPassenger(
            @PathVariable Long id,
            @RequestParam Long passengerId) {
        return ResponseEntity.ok(rideJoinService.cancelByPassenger(id, passengerId));
    }

    // PASSENGER: list own joins
    @GetMapping("/passenger/{passengerId}")
    @PreAuthorize("hasRole('PASSENGER')")
    public ResponseEntity<List<RideJoinResponse>> getByPassenger(@PathVariable Long passengerId) {
        return ResponseEntity.ok(rideJoinService.getJoinsByPassenger(passengerId));
    }

    // DRIVER/PASSENGER: view joins for a ride (any logged-in user)
    @GetMapping("/ride/{rideOfferId}")
    public ResponseEntity<List<RideJoinResponse>> getByRide(@PathVariable Long rideOfferId) {
        return ResponseEntity.ok(rideJoinService.getJoinsByRideOffer(rideOfferId));
    }
}
