package com.ridemate.bikepoolingsystem.service;

import com.ridemate.bikepoolingsystem.dto.file.FileUploadResponse;
import com.ridemate.bikepoolingsystem.entity.FileUpload;
import org.springframework.web.multipart.MultipartFile;

public interface FileUploadService {

    FileUploadResponse uploadDriverLicense(Long driverId, MultipartFile file);

    FileUpload getFileEntity(Long fileId);
}
