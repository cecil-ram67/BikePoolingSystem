package com.ridemate.bikepoolingsystem.enumtype;

public enum RideJoinStatus {

    REQUESTED,
    APPROVED,
    REJECTED,
    CANCELLED

}
