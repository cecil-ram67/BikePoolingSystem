package com.ridemate.bikepoolingsystem.dto.ride;

import jakarta.validation.constraints.*;

import java.time.LocalDate;
import java.time.LocalTime;

public record RideOfferCreateRequest(

        @NotNull(message = "Driver ID is required")
        Long driverId,

        @NotNull(message = "Bike ID is required")
        Long bikeId,

        @NotBlank(message = "Origin is required")
        String origin,

        @NotBlank(message = "Destination is required")
        String destination,

        @NotNull(message = "Travel date is required")
        LocalDate travelDate,

        @NotNull(message = "Departure time is required")
        LocalTime departureTime,

        @NotNull(message = "Total seats is required")
        @Min(value = 1, message = "Total seats must be at least 1")
        @Max(value = 2, message = "Total seats cannot be more than 2")
        Integer totalSeats,

        @NotNull(message = "Distance in km is required")
        @Positive(message = "Distance must be positive")
        Double distanceInKm
) {
}
