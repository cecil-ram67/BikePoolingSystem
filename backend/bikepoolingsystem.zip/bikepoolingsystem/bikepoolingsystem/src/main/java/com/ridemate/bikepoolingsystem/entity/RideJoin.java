package com.ridemate.bikepoolingsystem.entity;

import com.ridemate.bikepoolingsystem.enumtype.RideJoinStatus;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "ride_joins")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RideJoin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Ride being joined
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ride_offer_id", nullable = false)
    private RideOffer rideOffer;

    // Passenger joining
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "passenger_id", nullable = false)
    private User passenger;

    // Fare for this passenger (copied from rideOffer.farePerSeat at approval time)
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal fareAmount;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private RideJoinStatus status;

    // Cancellation related
    @Column(precision = 10, scale = 2)
    private BigDecimal cancellationCharge;

    @Column(precision = 10, scale = 2)
    private BigDecimal refundAmount;

    private LocalDateTime cancelledAt;

    @Column(nullable = false)
    private Boolean isDeleted = false;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    public void onCreate() {
        LocalDateTime now = LocalDateTime.now();
        this.createdAt = now;
        this.updatedAt = now;
        if (isDeleted == null) {
            isDeleted = false;
        }
    }

    @PreUpdate
    public void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
