package com.ridemate.bikepoolingsystem.service.impl;

import com.ridemate.bikepoolingsystem.dto.auth.AuthResponse;
import com.ridemate.bikepoolingsystem.dto.auth.LoginRequest;
import com.ridemate.bikepoolingsystem.dto.auth.RegisterRequest;
import com.ridemate.bikepoolingsystem.dto.user.UserDto;
import com.ridemate.bikepoolingsystem.entity.User;
import com.ridemate.bikepoolingsystem.exception.BadRequestException;
import com.ridemate.bikepoolingsystem.exception.ResourceNotFoundException;
import com.ridemate.bikepoolingsystem.repository.UserRepository;
import com.ridemate.bikepoolingsystem.security.JwtService;
import com.ridemate.bikepoolingsystem.security.UserPrincipal;
import com.ridemate.bikepoolingsystem.service.AuthService;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final ModelMapper modelMapper;
    private final JwtService jwtService;

    public AuthServiceImpl(UserRepository userRepository,
                           PasswordEncoder passwordEncoder,
                           ModelMapper modelMapper,
                           JwtService jwtService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.modelMapper = modelMapper;
        this.jwtService = jwtService;
    }

    @Override
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmailAndIsDeletedFalse(request.email())) {
            throw new BadRequestException("Email is already registered");
        }

        User user = User.builder()
                .fullName(request.fullName())
                .email(request.email())
                .password(passwordEncoder.encode(request.password()))
                .phoneNumber(request.phoneNumber())
                .role(request.role())
                .isDeleted(false)
                .build();

        User savedUser = userRepository.save(user);
        UserDto userDto = modelMapper.map(savedUser, UserDto.class);

        UserPrincipal principal = UserPrincipal.fromUser(savedUser);
        String token = jwtService.generateToken(principal);

        return new AuthResponse("User registered successfully", token, userDto);
    }

    @Override
    public AuthResponse login(LoginRequest request) {
        User user = userRepository.findByEmailAndIsDeletedFalse(request.email())
                .orElseThrow(() ->
                        new ResourceNotFoundException("Invalid email or password"));

        if (!passwordEncoder.matches(request.password(), user.getPassword())) {
            throw new BadRequestException("Invalid email or password");
        }

        UserDto userDto = modelMapper.map(user, UserDto.class);
        UserPrincipal principal = UserPrincipal.fromUser(user);
        String token = jwtService.generateToken(principal);

        return new AuthResponse("Login successful", token, userDto);
    }
}
