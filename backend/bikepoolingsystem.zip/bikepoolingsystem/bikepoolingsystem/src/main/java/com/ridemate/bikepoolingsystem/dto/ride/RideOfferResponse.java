package com.ridemate.bikepoolingsystem.dto.ride;

import com.ridemate.bikepoolingsystem.enumtype.RideStatus;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public record RideOfferResponse(
        Long id,
        Long driverId,
        String driverName,
        Long bikeId,
        String bikeBrand,
        String bikeModel,
        String origin,
        String destination,
        LocalDate travelDate,
        LocalTime departureTime,
        Integer totalSeats,
        Integer availableSeats,
        Double distanceInKm,
        BigDecimal farePerSeat,
        RideStatus status,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {
}
