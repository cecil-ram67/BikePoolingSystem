package com.ridemate.bikepoolingsystem.service;

import com.ridemate.bikepoolingsystem.dto.auth.AuthResponse;
import com.ridemate.bikepoolingsystem.dto.auth.LoginRequest;
import com.ridemate.bikepoolingsystem.dto.auth.RegisterRequest;

public interface AuthService {

    AuthResponse register(RegisterRequest request);

    AuthResponse login(LoginRequest request);
}
