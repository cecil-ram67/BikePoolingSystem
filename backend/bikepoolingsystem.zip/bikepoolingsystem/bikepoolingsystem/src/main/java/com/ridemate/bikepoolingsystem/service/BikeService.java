package com.ridemate.bikepoolingsystem.service;

import com.ridemate.bikepoolingsystem.dto.bike.BikeCreateRequest;
import com.ridemate.bikepoolingsystem.dto.bike.BikeResponse;
import com.ridemate.bikepoolingsystem.dto.bike.BikeUpdateRequest;

import java.util.List;

public interface BikeService {

    BikeResponse createBike(BikeCreateRequest request);

    BikeResponse updateBike(Long bikeId, BikeUpdateRequest request);

    BikeResponse getBikeById(Long bikeId);

    List<BikeResponse> getBikesByDriver(Long driverId);

    void softDeleteBike(Long bikeId);
}
