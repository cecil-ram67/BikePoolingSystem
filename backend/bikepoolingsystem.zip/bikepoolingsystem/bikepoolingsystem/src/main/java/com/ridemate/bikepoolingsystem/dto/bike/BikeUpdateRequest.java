package com.ridemate.bikepoolingsystem.dto.bike;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record BikeUpdateRequest(

        @NotBlank(message = "Brand is required")
        String brand,

        @NotBlank(message = "Model is required")
        String model,

        @Size(max = 50, message = "Registration number max length is 50")
        String registrationNumber,

        @Min(value = 1, message = "Max seats must be at least 1")
        @Max(value = 2, message = "Max seats cannot be more than 2")
        Integer maxSeats,

        Boolean isActive
) {
}
