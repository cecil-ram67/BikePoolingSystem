package com.ridemate.bikepoolingsystem.enumtype;

public enum Role {
    DRIVER,
    PASSENGER,
    ADMIN
}
