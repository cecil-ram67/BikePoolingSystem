package com.ridemate.bikepoolingsystem.dto.ride;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Positive;

import java.time.LocalDate;
import java.time.LocalTime;

public record RideOfferUpdateRequest(

        String origin,
        String destination,
        LocalDate travelDate,
        LocalTime departureTime,

        @Min(value = 1, message = "Total seats must be at least 1")
        @Max(value = 2, message = "Total seats cannot be more than 2")
        Integer totalSeats,

        @Positive(message = "Distance must be positive")
        Double distanceInKm
) {
}
