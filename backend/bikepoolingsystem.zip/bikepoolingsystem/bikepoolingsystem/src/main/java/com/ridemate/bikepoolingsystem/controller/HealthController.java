package com.ridemate.bikepoolingsystem.controller;

import com.ridemate.bikepoolingsystem.dto.HealthResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;

@RestController
public class HealthController {

    @GetMapping("/api/health")
    public HealthResponse health() {
        return new HealthResponse(
                "OK",
                Instant.now(),
                "RideMate BikePoolingSystem Backend"
        );
    }
}
