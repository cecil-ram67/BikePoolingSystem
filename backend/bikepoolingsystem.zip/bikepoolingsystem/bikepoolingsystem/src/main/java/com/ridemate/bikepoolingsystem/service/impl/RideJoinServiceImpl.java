package com.ridemate.bikepoolingsystem.service.impl;

import com.ridemate.bikepoolingsystem.config.RideJoinConfig;
import com.ridemate.bikepoolingsystem.dto.ridejoin.RideJoinRequest;
import com.ridemate.bikepoolingsystem.dto.ridejoin.RideJoinResponse;
import com.ridemate.bikepoolingsystem.entity.RideJoin;
import com.ridemate.bikepoolingsystem.entity.RideOffer;
import com.ridemate.bikepoolingsystem.entity.User;
import com.ridemate.bikepoolingsystem.enumtype.RideJoinStatus;
import com.ridemate.bikepoolingsystem.enumtype.RideStatus;
import com.ridemate.bikepoolingsystem.enumtype.Role;
import com.ridemate.bikepoolingsystem.exception.BadRequestException;
import com.ridemate.bikepoolingsystem.exception.ResourceNotFoundException;
import com.ridemate.bikepoolingsystem.repository.RideJoinRepository;
import com.ridemate.bikepoolingsystem.repository.RideOfferRepository;
import com.ridemate.bikepoolingsystem.repository.UserRepository;
import com.ridemate.bikepoolingsystem.service.RideJoinService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Set;

@Service
public class RideJoinServiceImpl implements RideJoinService {

    // 20% deduction on cancel before departure
//    private static final BigDecimal CANCELLATION_DEDUCTION_PERCENT = BigDecimal.valueOf(0.20);

    private RideJoinConfig rideJoinConfig;
    private RideOfferRepository rideOfferRepository;
    private UserRepository userRepository;
    private RideJoinRepository rideJoinRepository;
    public RideJoinServiceImpl(
            RideJoinRepository rideJoinRepository,
            RideOfferRepository rideOfferRepository,
            UserRepository userRepository,
            RideJoinConfig rideJoinConfig
    ) {
        this.rideJoinRepository = rideJoinRepository;
        this.rideOfferRepository = rideOfferRepository;
        this.userRepository = userRepository;
        this.rideJoinConfig = rideJoinConfig;
    }

    @Override
    public RideJoinResponse requestToJoin(RideJoinRequest request) {
        User passenger = userRepository.findByIdAndIsDeletedFalse(request.passengerId())
                .orElseThrow(() ->
                        new ResourceNotFoundException("Passenger not found with id: " + request.passengerId()));

        if (passenger.getRole() != Role.PASSENGER) {
            throw new BadRequestException("User with id " + passenger.getId() + " is not a PASSENGER");
        }

        RideOffer rideOffer = rideOfferRepository.findByIdAndIsDeletedFalse(request.rideOfferId())
                .orElseThrow(() ->
                        new ResourceNotFoundException("Ride offer not found with id: " + request.rideOfferId()));

        if (rideOffer.getDriver().getId().equals(passenger.getId())) {
            throw new BadRequestException("Driver cannot join their own ride as passenger");
        }

        if (rideOffer.getStatus() != RideStatus.OPEN) {
            throw new BadRequestException("Ride is not open for joining");
        }

        if (rideOffer.getAvailableSeats() <= 0) {
            throw new BadRequestException("No seats available for this ride");
        }

        boolean alreadyRequested = rideJoinRepository
                .existsByRideOfferIdAndPassengerIdAndIsDeletedFalseAndStatusIn(
                        rideOffer.getId(),
                        passenger.getId(),
                        Set.of(RideJoinStatus.REQUESTED, RideJoinStatus.APPROVED)
                );

        if (alreadyRequested) {
            throw new BadRequestException("Passenger already has a pending/approved request for this ride");
        }

        RideJoin rideJoin = RideJoin.builder()
                .rideOffer(rideOffer)
                .passenger(passenger)
                .fareAmount(BigDecimal.ZERO) // will be set at approval
                .status(RideJoinStatus.REQUESTED)
                .isDeleted(false)
                .build();

        RideJoin saved = rideJoinRepository.save(rideJoin);
        return toResponse(saved);
    }

    @Override
    public RideJoinResponse approveJoin(Long rideJoinId, Long driverId) {
        RideJoin rideJoin = rideJoinRepository.findByIdAndIsDeletedFalse(rideJoinId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Ride join request not found with id: " + rideJoinId));

        RideOffer rideOffer = rideJoin.getRideOffer();

        if (!rideOffer.getDriver().getId().equals(driverId)) {
            throw new BadRequestException("Only the driver of this ride can approve requests");
        }

        if (rideJoin.getStatus() != RideJoinStatus.REQUESTED) {
            throw new BadRequestException("Only REQUESTED joins can be approved");
        }

        if (rideOffer.getStatus() != RideStatus.OPEN) {
            throw new BadRequestException("Ride is not open");
        }

        if (rideOffer.getAvailableSeats() <= 0) {
            throw new BadRequestException("No seats available to approve this request");
        }

        // approve and assign fare
        rideJoin.setStatus(RideJoinStatus.APPROVED);
        rideJoin.setFareAmount(rideOffer.getFarePerSeat());

        // reduce available seats
        rideOffer.setAvailableSeats(rideOffer.getAvailableSeats() - 1);
        if (rideOffer.getAvailableSeats() == 0) {
            rideOffer.setStatus(RideStatus.FULL);
        }

        RideJoin updatedJoin = rideJoinRepository.save(rideJoin);
        rideOfferRepository.save(rideOffer);

        return toResponse(updatedJoin);
    }

    @Override
    public RideJoinResponse rejectJoin(Long rideJoinId, Long driverId) {
        RideJoin rideJoin = rideJoinRepository.findByIdAndIsDeletedFalse(rideJoinId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Ride join request not found with id: " + rideJoinId));

        RideOffer rideOffer = rideJoin.getRideOffer();

        if (!rideOffer.getDriver().getId().equals(driverId)) {
            throw new BadRequestException("Only the driver of this ride can reject requests");
        }

        if (rideJoin.getStatus() != RideJoinStatus.REQUESTED) {
            throw new BadRequestException("Only REQUESTED joins can be rejected");
        }

        rideJoin.setStatus(RideJoinStatus.REJECTED);
        RideJoin updatedJoin = rideJoinRepository.save(rideJoin);

        return toResponse(updatedJoin);
    }

    @Override
    public RideJoinResponse cancelByPassenger(Long rideJoinId, Long passengerId) {
        RideJoin rideJoin = rideJoinRepository.findByIdAndIsDeletedFalse(rideJoinId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Ride join not found with id: " + rideJoinId));

        if (!rideJoin.getPassenger().getId().equals(passengerId)) {
            throw new BadRequestException("Only the passenger who booked can cancel this join");
        }
        if (rideJoin.getStatus() == RideJoinStatus.APPROVED) {
            BigDecimal fare = rideJoin.getFareAmount();
            if (fare == null) {
                throw new BadRequestException("Fare amount not set for this approved join");
            }
        }

        if (rideJoin.getStatus() != RideJoinStatus.APPROVED &&
                rideJoin.getStatus() != RideJoinStatus.REQUESTED) {
            throw new BadRequestException("Only REQUESTED or APPROVED joins can be cancelled");
        }

        RideOffer rideOffer = rideJoin.getRideOffer();

        // check if before departure time
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime departureDateTime = LocalDateTime.of(
                rideOffer.getTravelDate(),
                rideOffer.getDepartureTime() != null ? rideOffer.getDepartureTime() : LocalTime.MIDNIGHT
        );

        BigDecimal cancellationCharge = BigDecimal.ZERO;
        BigDecimal refundAmount = BigDecimal.ZERO;

        if (rideJoin.getStatus() == RideJoinStatus.APPROVED) {
            BigDecimal fare = rideJoin.getFareAmount();

            if (now.isBefore(departureDateTime)) {
                // before departure → deduct some amount
                BigDecimal percentage = rideJoinConfig.getCancellationPercent();

                cancellationCharge = fare.multiply(percentage)
                        .setScale(2, RoundingMode.HALF_UP);

                refundAmount = fare.subtract(cancellationCharge)
                        .setScale(2, RoundingMode.HALF_UP);
            } else {
                // after departure → no refund
                cancellationCharge = fare;
                refundAmount = BigDecimal.ZERO;
            }

            // if ride is still active, return seat back
            if (rideOffer.getStatus() == RideStatus.OPEN || rideOffer.getStatus() == RideStatus.FULL) {
                rideOffer.setAvailableSeats(rideOffer.getAvailableSeats() + 1);
                if (rideOffer.getStatus() == RideStatus.FULL &&
                        rideOffer.getAvailableSeats() > 0) {
                    rideOffer.setStatus(RideStatus.OPEN);
                }
                rideOfferRepository.save(rideOffer);
            }
        }

        rideJoin.setStatus(RideJoinStatus.CANCELLED);
        rideJoin.setCancellationCharge(cancellationCharge);
        rideJoin.setRefundAmount(refundAmount);
        rideJoin.setCancelledAt(LocalDateTime.now());

        RideJoin updated = rideJoinRepository.save(rideJoin);
        return toResponse(updated);
    }

    @Override
    public List<RideJoinResponse> getJoinsByPassenger(Long passengerId) {
        List<RideJoin> joins = rideJoinRepository.findAllByPassengerIdAndIsDeletedFalse(passengerId);
        return joins.stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    public List<RideJoinResponse> getJoinsByRideOffer(Long rideOfferId) {
        List<RideJoin> joins = rideJoinRepository.findAllByRideOfferIdAndIsDeletedFalse(rideOfferId);
        return joins.stream()
                .map(this::toResponse)
                .toList();
    }

    private RideJoinResponse toResponse(RideJoin join) {
        RideOffer ride = join.getRideOffer();
        return new RideJoinResponse(
                join.getId(),
                ride.getId(),
                join.getPassenger().getId(),
                join.getPassenger().getFullName(),
                ride.getOrigin(),
                ride.getDestination(),
                ride.getTravelDate(),
                ride.getDepartureTime(),
                join.getFareAmount(),
                join.getCancellationCharge(),
                join.getRefundAmount(),
                join.getStatus(),
                join.getCreatedAt(),
                join.getUpdatedAt(),
                join.getCancelledAt()
        );
    }
}
