package com.ridemate.bikepoolingsystem.dto.file;

import com.ridemate.bikepoolingsystem.enumtype.FileType;

import java.time.LocalDateTime;

public record FileUploadResponse(
        Long id,
        Long ownerId,
        FileType fileType,
        String originalFileName,
        String storedFileName,
        String downloadUrl,
        String contentType,
        Long fileSize,
        LocalDateTime uploadedAt
) {
}
