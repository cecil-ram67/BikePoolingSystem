package com.ridemate.bikepoolingsystem.controller;

import com.ridemate.bikepoolingsystem.dto.auth.AuthResponse;
import com.ridemate.bikepoolingsystem.dto.auth.LoginRequest;
import com.ridemate.bikepoolingsystem.dto.auth.RegisterRequest;
import com.ridemate.bikepoolingsystem.dto.user.UserDto;
import com.ridemate.bikepoolingsystem.entity.User;
import com.ridemate.bikepoolingsystem.exception.ResourceNotFoundException;
import com.ridemate.bikepoolingsystem.repository.UserRepository;
import com.ridemate.bikepoolingsystem.security.UserPrincipal;
import com.ridemate.bikepoolingsystem.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final UserRepository userRepository;

    public AuthController(AuthService authService,
                          UserRepository userRepository) {
        this.authService = authService;
        this.userRepository = userRepository;
    }

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.ok(authService.register(request));
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }

    // Get current authenticated user
    @GetMapping("/me")
    public ResponseEntity<UserDto> me(@AuthenticationPrincipal UserPrincipal principal) {
        if (principal == null) {
            throw new ResourceNotFoundException("User not authenticated");
        }

        User user = userRepository.findByIdAndIsDeletedFalse(principal.getId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        UserDto userDto = new UserDto(
                user.getId(),
                user.getFullName(),
                user.getEmail(),
                user.getPhoneNumber(),
                user.getRole(),
                user.getCreatedAt(),
                user.getUpdatedAt()
        );

        return ResponseEntity.ok(userDto);
    }
}
