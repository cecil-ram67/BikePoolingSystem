package com.ridemate.bikepoolingsystem.dto.bike;

import java.time.LocalDateTime;

public record BikeResponse(
        Long id,
        Long driverId,
        String driverName,
        String brand,
        String model,
        String registrationNumber,
        Integer maxSeats,
        Boolean isActive,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {
}
