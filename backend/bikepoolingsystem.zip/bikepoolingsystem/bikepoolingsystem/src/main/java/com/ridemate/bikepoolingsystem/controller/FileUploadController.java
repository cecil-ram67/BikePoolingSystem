package com.ridemate.bikepoolingsystem.controller;

import com.ridemate.bikepoolingsystem.dto.file.FileUploadResponse;
import com.ridemate.bikepoolingsystem.entity.FileUpload;
import com.ridemate.bikepoolingsystem.service.FileUploadService;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
@RequestMapping("/api/files")
public class FileUploadController {

    private final FileUploadService fileUploadService;

    public FileUploadController(FileUploadService fileUploadService) {
        this.fileUploadService = fileUploadService;
    }

    // DRIVER: upload license
    @PostMapping(value = "/driver-license", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<FileUploadResponse> uploadDriverLicense(
            @RequestParam("driverId") Long driverId,
            @RequestPart("file") MultipartFile file) {

        FileUploadResponse response = fileUploadService.uploadDriverLicense(driverId, file);
        return ResponseEntity.ok(response);
    }

    // PUBLIC: download file
    @GetMapping("/{id}")
    public ResponseEntity<Resource> downloadFile(@PathVariable Long id) {
        FileUpload fileUpload = fileUploadService.getFileEntity(id);

        Path filePath = Paths.get(fileUpload.getFilePath()).toAbsolutePath().normalize();
        Resource resource;
        try {
            resource = new UrlResource(filePath.toUri());
        } catch (MalformedURLException e) {
            throw new RuntimeException("Error reading file", e);
        }

        if (!resource.exists()) {
            return ResponseEntity.notFound().build();
        }

        String contentType;
        try {
            contentType = Files.probeContentType(filePath);
        } catch (Exception e) {
            contentType = fileUpload.getContentType();
        }

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType != null ? contentType : "application/octet-stream"))
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "inline; filename=\"" + fileUpload.getOriginalFileName() + "\"")
                .body(resource);
    }
}
