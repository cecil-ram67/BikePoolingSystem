package com.ridemate.bikepoolingsystem.dto.auth;

import com.ridemate.bikepoolingsystem.dto.user.UserDto;

public record AuthResponse(
        String message,
        String token,   // will be real JWT later
        UserDto user
) {
}
