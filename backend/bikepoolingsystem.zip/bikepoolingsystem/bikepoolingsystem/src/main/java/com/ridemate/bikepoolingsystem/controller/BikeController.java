package com.ridemate.bikepoolingsystem.controller;

import com.ridemate.bikepoolingsystem.dto.bike.BikeCreateRequest;
import com.ridemate.bikepoolingsystem.dto.bike.BikeResponse;
import com.ridemate.bikepoolingsystem.dto.bike.BikeUpdateRequest;
import com.ridemate.bikepoolingsystem.service.BikeService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bikes")
public class BikeController {

    private final BikeService bikeService;

    public BikeController(BikeService bikeService) {
        this.bikeService = bikeService;
    }
    // DRIVER: create bike
    @PostMapping
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<BikeResponse> createBike(@Valid @RequestBody BikeCreateRequest request) {
        return ResponseEntity.ok(bikeService.createBike(request));
    }

    // DRIVER: update own bike (for now only role, not ownership check)
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<BikeResponse> updateBike(
            @PathVariable Long id,
            @Valid @RequestBody BikeUpdateRequest request) {
        return ResponseEntity.ok(bikeService.updateBike(id, request));
    }

    // DRIVER: soft delete bike
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<Void> deleteBike(@PathVariable Long id) {
        bikeService.softDeleteBike(id);
        return ResponseEntity.noContent().build();
    }

    // DRIVER: view bikes by driver
    @GetMapping("/driver/{driverId}")
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<List<BikeResponse>> getBikesByDriver(@PathVariable Long driverId) {
        return ResponseEntity.ok(bikeService.getBikesByDriver(driverId));
    }

    // AUTHENTICATED: get bike by id (any logged-in user can see)
    @GetMapping("/{id}")
    public ResponseEntity<BikeResponse> getBikeById(@PathVariable Long id) {
        return ResponseEntity.ok(bikeService.getBikeById(id));
    }
}
