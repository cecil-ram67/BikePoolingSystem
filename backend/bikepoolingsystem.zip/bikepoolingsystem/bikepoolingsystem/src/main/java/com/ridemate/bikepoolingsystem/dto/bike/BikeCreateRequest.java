package com.ridemate.bikepoolingsystem.dto.bike;

import jakarta.validation.constraints.*;

public record BikeCreateRequest(

        @NotNull(message = "Driver ID is required")
        Long driverId,

        @NotBlank(message = "Brand is required")
        String brand,

        @NotBlank(message = "Model is required")
        String model,

        @NotBlank(message = "Registration number is required")
        @Size(max = 50, message = "Registration number max length is 50")
        String registrationNumber,

        @NotNull(message = "Max seats is required")
        @Min(value = 1, message = "Max seats must be at least 1")
        @Max(value = 2, message = "Max seats cannot be more than 2")
        Integer maxSeats
) {
}
