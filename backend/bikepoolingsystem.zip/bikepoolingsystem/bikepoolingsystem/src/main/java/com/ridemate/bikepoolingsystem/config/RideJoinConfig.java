package com.ridemate.bikepoolingsystem.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;

@Configuration
public class RideJoinConfig {

    // Inject from properties, default to 20%
    @Value("${ridejoin.cancellation.percent:0.20}")
    private BigDecimal cancellationPercent;

    public BigDecimal getCancellationPercent() {
        return cancellationPercent;
    }
}
