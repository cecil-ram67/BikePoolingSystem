package com.ridemate.bikepoolingsystem.service;

import com.ridemate.bikepoolingsystem.dto.ridejoin.RideJoinRequest;
import com.ridemate.bikepoolingsystem.dto.ridejoin.RideJoinResponse;

import java.util.List;

public interface RideJoinService {

    RideJoinResponse requestToJoin(RideJoinRequest request);

    RideJoinResponse approveJoin(Long rideJoinId, Long driverId);

    RideJoinResponse rejectJoin(Long rideJoinId, Long driverId);

    RideJoinResponse cancelByPassenger(Long rideJoinId, Long passengerId);

    List<RideJoinResponse> getJoinsByPassenger(Long passengerId);

    List<RideJoinResponse> getJoinsByRideOffer(Long rideOfferId);
}
