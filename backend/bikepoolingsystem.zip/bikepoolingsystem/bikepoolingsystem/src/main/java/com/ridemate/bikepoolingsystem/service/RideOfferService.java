package com.ridemate.bikepoolingsystem.service;

import com.ridemate.bikepoolingsystem.dto.ride.RideOfferCreateRequest;
import com.ridemate.bikepoolingsystem.dto.ride.RideOfferResponse;
import com.ridemate.bikepoolingsystem.dto.ride.RideOfferUpdateRequest;

import java.time.LocalDate;
import java.util.List;

public interface RideOfferService {

    RideOfferResponse createRideOffer(RideOfferCreateRequest request);

    RideOfferResponse updateRideOffer(Long rideOfferId, RideOfferUpdateRequest request);

    RideOfferResponse getRideOfferById(Long rideOfferId);

    List<RideOfferResponse> getRideOffersByDriver(Long driverId);

    List<RideOfferResponse> searchRides(String origin, String destination, LocalDate travelDate);

    RideOfferResponse cancelRideOffer(Long rideOfferId);

    RideOfferResponse completeRideOffer(Long rideOfferId);
    List<RideOfferResponse> searchRideOffers(String origin, String destination, String travelDate);
}
