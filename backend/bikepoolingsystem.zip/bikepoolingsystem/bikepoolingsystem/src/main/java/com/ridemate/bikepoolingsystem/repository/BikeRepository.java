package com.ridemate.bikepoolingsystem.repository;

import com.ridemate.bikepoolingsystem.entity.Bike;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface BikeRepository extends JpaRepository<Bike, Long> {

    Optional<Bike> findByIdAndIsDeletedFalse(Long id);

    List<Bike> findAllByDriverIdAndIsDeletedFalse(Long driverId);

    boolean existsByRegistrationNumberAndIsDeletedFalse(String registrationNumber);
}
