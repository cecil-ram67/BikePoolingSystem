package com.ridemate.bikepoolingsystem.service.impl;

import com.ridemate.bikepoolingsystem.dto.ride.RideOfferCreateRequest;
import com.ridemate.bikepoolingsystem.dto.ride.RideOfferResponse;
import com.ridemate.bikepoolingsystem.dto.ride.RideOfferUpdateRequest;
import com.ridemate.bikepoolingsystem.entity.Bike;
import com.ridemate.bikepoolingsystem.entity.RideOffer;
import com.ridemate.bikepoolingsystem.entity.User;
import com.ridemate.bikepoolingsystem.enumtype.RideStatus;
import com.ridemate.bikepoolingsystem.enumtype.Role;
import com.ridemate.bikepoolingsystem.exception.BadRequestException;
import com.ridemate.bikepoolingsystem.exception.ResourceNotFoundException;
import com.ridemate.bikepoolingsystem.repository.BikeRepository;
import com.ridemate.bikepoolingsystem.repository.RideOfferRepository;
import com.ridemate.bikepoolingsystem.repository.UserRepository;
import com.ridemate.bikepoolingsystem.service.RideOfferService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;

@Service
public class RideOfferServiceImpl implements RideOfferService {
    private final ModelMapper modelMapper;


    private static final double BASE_FARE_PER_KM = 3.0;
    private static final double WEEKEND_SURGE = 1.0; // +1 on Sat/Sun
    private static final double MINIMUM_FARE = 50.0;

    private final RideOfferRepository rideOfferRepository;
    private final UserRepository userRepository;
    private final BikeRepository bikeRepository;

    public RideOfferServiceImpl(RideOfferRepository rideOfferRepository,
                                UserRepository userRepository,
                                BikeRepository bikeRepository,
                                ModelMapper modelMapper) {
        this.rideOfferRepository = rideOfferRepository;
        this.userRepository = userRepository;
        this.bikeRepository = bikeRepository;
        this.modelMapper=modelMapper;
    }

    @Override
    public RideOfferResponse createRideOffer(RideOfferCreateRequest request) {
        User driver = userRepository.findByIdAndIsDeletedFalse(request.driverId())
                .orElseThrow(() ->
                        new ResourceNotFoundException("Driver not found with id: " + request.driverId()));

        if (driver.getRole() != Role.DRIVER) {
            throw new BadRequestException("User with id " + driver.getId() + " is not a DRIVER");
        }

        Bike bike = bikeRepository.findByIdAndIsDeletedFalse(request.bikeId())
                .orElseThrow(() ->
                        new ResourceNotFoundException("Bike not found with id: " + request.bikeId()));

        if (!bike.getDriver().getId().equals(driver.getId())) {
            throw new BadRequestException("Bike does not belong to the given driver");
        }

        if (!Boolean.TRUE.equals(bike.getIsActive()) || Boolean.TRUE.equals(bike.getIsDeleted())) {
            throw new BadRequestException("Bike is not active or is deleted");
        }

        if (request.totalSeats() > bike.getMaxSeats()) {
            throw new BadRequestException("Total seats cannot exceed bike maxSeats (" + bike.getMaxSeats() + ")");
        }

        BigDecimal farePerSeat = calculateFarePerSeat(request.distanceInKm(), request.travelDate());

        RideOffer rideOffer = RideOffer.builder()
                .driver(driver)
                .bike(bike)
                .origin(request.origin())
                .destination(request.destination())
                .travelDate(request.travelDate())
                .departureTime(request.departureTime())
                .totalSeats(request.totalSeats())
                .availableSeats(request.totalSeats())
                .distanceInKm(request.distanceInKm())
                .farePerSeat(farePerSeat)
                .status(RideStatus.OPEN)
                .isDeleted(false)
                .build();

        RideOffer saved = rideOfferRepository.save(rideOffer);
        return toResponse(saved);
    }

    @Override
    public RideOfferResponse updateRideOffer(Long rideOfferId, RideOfferUpdateRequest request) {
        RideOffer rideOffer = rideOfferRepository.findByIdAndIsDeletedFalse(rideOfferId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Ride offer not found with id: " + rideOfferId));

        if (rideOffer.getStatus() == RideStatus.COMPLETED || rideOffer.getStatus() == RideStatus.CANCELLED) {
            throw new BadRequestException("Cannot update a completed or cancelled ride");
        }

        if (request.origin() != null && !request.origin().isBlank()) {
            rideOffer.setOrigin(request.origin());
        }
        if (request.destination() != null && !request.destination().isBlank()) {
            rideOffer.setDestination(request.destination());
        }
        if (request.travelDate() != null) {
            rideOffer.setTravelDate(request.travelDate());
        }
        if (request.departureTime() != null) {
            rideOffer.setDepartureTime(request.departureTime());
        }

        if (request.totalSeats() != null) {
            int newTotalSeats = request.totalSeats();
            if (newTotalSeats < 1 || newTotalSeats > 2) {
                throw new BadRequestException("Total seats must be between 1 and 2");
            }

            int alreadyBooked = rideOffer.getTotalSeats() - rideOffer.getAvailableSeats();
            if (newTotalSeats < alreadyBooked) {
                throw new BadRequestException("Total seats cannot be less than already booked seats (" + alreadyBooked + ")");
            }

            rideOffer.setTotalSeats(newTotalSeats);
            rideOffer.setAvailableSeats(newTotalSeats - alreadyBooked);
        }

        if (request.distanceInKm() != null && request.distanceInKm() > 0) {
            rideOffer.setDistanceInKm(request.distanceInKm());
            BigDecimal newFare = calculateFarePerSeat(request.distanceInKm(), rideOffer.getTravelDate());
            rideOffer.setFarePerSeat(newFare);
        }

        RideOffer updated = rideOfferRepository.save(rideOffer);
        return toResponse(updated);
    }

    @Override
    public RideOfferResponse getRideOfferById(Long rideOfferId) {
        RideOffer rideOffer = rideOfferRepository.findByIdAndIsDeletedFalse(rideOfferId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Ride offer not found with id: " + rideOfferId));
        return toResponse(rideOffer);
    }

    @Override
    public List<RideOfferResponse> getRideOffersByDriver(Long driverId) {
        List<RideOffer> offers = rideOfferRepository.findAllByDriverIdAndIsDeletedFalse(driverId);
        return offers.stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    public List<RideOfferResponse> searchRides(String origin, String destination, LocalDate travelDate) {
        List<RideOffer> offers = rideOfferRepository
                .findByOriginIgnoreCaseAndDestinationIgnoreCaseAndTravelDateAndIsDeletedFalseAndStatus(
                        origin, destination, travelDate, RideStatus.OPEN
                );
        return offers.stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    public RideOfferResponse cancelRideOffer(Long rideOfferId) {
        RideOffer rideOffer = rideOfferRepository.findByIdAndIsDeletedFalse(rideOfferId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Ride offer not found with id: " + rideOfferId));
        rideOffer.setStatus(RideStatus.CANCELLED);
        RideOffer updated = rideOfferRepository.save(rideOffer);
        return toResponse(updated);
    }

    @Override
    public RideOfferResponse completeRideOffer(Long rideOfferId) {
        RideOffer rideOffer = rideOfferRepository.findByIdAndIsDeletedFalse(rideOfferId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Ride offer not found with id: " + rideOfferId));
        rideOffer.setStatus(RideStatus.COMPLETED);
        RideOffer updated = rideOfferRepository.save(rideOffer);
        return toResponse(updated);
    }

    @Override
    public List<RideOfferResponse> searchRideOffers(String origin, String destination, String travelDate) {
        List<RideOffer> offers = rideOfferRepository.searchRideOffers(origin, destination, travelDate);
        return offers.stream()
                .map(o -> modelMapper.map(o, RideOfferResponse.class))
                .toList();
    }


    private BigDecimal calculateFarePerSeat(Double distanceInKm, LocalDate travelDate) {
        double surge = 0.0;
        DayOfWeek day = travelDate.getDayOfWeek();
        if (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) {
            surge += WEEKEND_SURGE;
        }

        double farePerKm = BASE_FARE_PER_KM + surge;
        double rawFare = distanceInKm * farePerKm;
        double finalFare = Math.max(rawFare, MINIMUM_FARE);

        return BigDecimal.valueOf(finalFare).setScale(2, RoundingMode.HALF_UP);
    }

    private RideOfferResponse toResponse(RideOffer rideOffer) {
        return new RideOfferResponse(
                rideOffer.getId(),
                rideOffer.getDriver().getId(),
                rideOffer.getDriver().getFullName(),
                rideOffer.getBike().getId(),
                rideOffer.getBike().getBrand(),
                rideOffer.getBike().getModel(),
                rideOffer.getOrigin(),
                rideOffer.getDestination(),
                rideOffer.getTravelDate(),
                rideOffer.getDepartureTime(),
                rideOffer.getTotalSeats(),
                rideOffer.getAvailableSeats(),
                rideOffer.getDistanceInKm(),
                rideOffer.getFarePerSeat(),
                rideOffer.getStatus(),
                rideOffer.getCreatedAt(),
                rideOffer.getUpdatedAt()
        );
    }
}
