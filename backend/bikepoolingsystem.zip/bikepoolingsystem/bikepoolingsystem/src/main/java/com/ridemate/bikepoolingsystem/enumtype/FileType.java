package com.ridemate.bikepoolingsystem.enumtype;

public enum FileType {
    DRIVER_LICENSE
}
