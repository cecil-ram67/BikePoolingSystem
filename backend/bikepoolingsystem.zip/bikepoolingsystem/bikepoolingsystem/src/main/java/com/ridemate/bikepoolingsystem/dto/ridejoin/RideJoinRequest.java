package com.ridemate.bikepoolingsystem.dto.ridejoin;

import jakarta.validation.constraints.NotNull;

public record RideJoinRequest(

        @NotNull(message = "Passenger ID is required")
        Long passengerId,

        @NotNull(message = "Ride offer ID is required")
        Long rideOfferId
) {
}
