package com.ridemate.bikepoolingsystem.repository;

import com.ridemate.bikepoolingsystem.entity.FileUpload;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface FileUploadRepository extends JpaRepository<FileUpload, Long> {

    Optional<FileUpload> findByIdAndIsDeletedFalse(Long id);
}
