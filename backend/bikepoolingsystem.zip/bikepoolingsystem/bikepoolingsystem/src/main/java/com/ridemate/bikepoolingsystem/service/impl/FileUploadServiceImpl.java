package com.ridemate.bikepoolingsystem.service.impl;

import com.ridemate.bikepoolingsystem.dto.file.FileUploadResponse;
import com.ridemate.bikepoolingsystem.entity.FileUpload;
import com.ridemate.bikepoolingsystem.entity.User;
import com.ridemate.bikepoolingsystem.enumtype.FileType;
import com.ridemate.bikepoolingsystem.enumtype.Role;
import com.ridemate.bikepoolingsystem.exception.BadRequestException;
import com.ridemate.bikepoolingsystem.exception.ResourceNotFoundException;
import com.ridemate.bikepoolingsystem.repository.FileUploadRepository;
import com.ridemate.bikepoolingsystem.repository.UserRepository;
import com.ridemate.bikepoolingsystem.service.FileUploadService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;

@Service
public class FileUploadServiceImpl implements FileUploadService {

    private final FileUploadRepository fileUploadRepository;
    private final UserRepository userRepository;

    private final Path licenseUploadDir;

    public FileUploadServiceImpl(FileUploadRepository fileUploadRepository,
                                 UserRepository userRepository,
                                 @Value("${file.upload.license-dir:uploads/licenses}") String licenseDir) {
        this.fileUploadRepository = fileUploadRepository;
        this.userRepository = userRepository;
        this.licenseUploadDir = Paths.get(licenseDir).toAbsolutePath().normalize();

        try {
            Files.createDirectories(this.licenseUploadDir);
        } catch (IOException e) {
            throw new RuntimeException("Could not create license upload directory", e);
        }
    }

    @Override
    public FileUploadResponse uploadDriverLicense(Long driverId, MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new BadRequestException("License file is required");
        }

        User driver = userRepository.findByIdAndIsDeletedFalse(driverId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Driver not found with id: " + driverId));

        if (driver.getRole() != Role.DRIVER) {
            throw new BadRequestException("User with id " + driverId + " is not a DRIVER");
        }

        String originalFilename = StringUtils.cleanPath(file.getOriginalFilename());
        if (!StringUtils.hasText(originalFilename)) {
            throw new BadRequestException("File name is invalid");
        }

        String extension = "";
        int dotIndex = originalFilename.lastIndexOf('.');
        if (dotIndex > 0 && dotIndex < originalFilename.length() - 1) {
            extension = originalFilename.substring(dotIndex);
        }

        // basic allowed types (extend later)
        String contentType = file.getContentType() != null ? file.getContentType() : "application/octet-stream";
        if (!contentType.startsWith("image/") && !contentType.equals("application/pdf")) {
            throw new BadRequestException("Only image or PDF files are allowed for license");
        }

        String storedFileName = "driver_" + driverId + "_" + System.currentTimeMillis() + extension;
        Path targetLocation = licenseUploadDir.resolve(storedFileName);

        try {
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new RuntimeException("Failed to store license file", e);
        }

        FileUpload upload = FileUpload.builder()
                .owner(driver)
                .fileType(FileType.DRIVER_LICENSE)
                .originalFileName(originalFilename)
                .storedFileName(storedFileName)
                .filePath(targetLocation.toString())
                .contentType(contentType)
                .fileSize(file.getSize())
                .isDeleted(false)
                .build();

        FileUpload saved = fileUploadRepository.save(upload);

        // mark user as having uploaded license
        driver.setLicenseFile(saved);
        driver.setLicenseUploaded(true);
        userRepository.save(driver);

        String downloadUrl = "/api/files/" + saved.getId();

        return new FileUploadResponse(
                saved.getId(),
                driver.getId(),
                saved.getFileType(),
                saved.getOriginalFileName(),
                saved.getStoredFileName(),
                downloadUrl,
                saved.getContentType(),
                saved.getFileSize(),
                saved.getUploadedAt()
        );
    }

    @Override
    public FileUpload getFileEntity(Long fileId) {
        return fileUploadRepository.findByIdAndIsDeletedFalse(fileId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("File not found with id: " + fileId));
    }
}
