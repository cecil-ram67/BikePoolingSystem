package com.ridemate.bikepoolingsystem.controller;

import com.ridemate.bikepoolingsystem.dto.ride.RideOfferCreateRequest;
import com.ridemate.bikepoolingsystem.dto.ride.RideOfferResponse;
import com.ridemate.bikepoolingsystem.service.RideOfferService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ride-offers")
public class RideOfferController {

    private final RideOfferService rideOfferService;

    public RideOfferController(RideOfferService rideOfferService) {
        this.rideOfferService = rideOfferService;
    }

    // DRIVER: create a ride offer
    @PostMapping
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<RideOfferResponse> createRideOffer(
            @Valid @RequestBody RideOfferCreateRequest request) {

        RideOfferResponse response = rideOfferService.createRideOffer(request);
        return ResponseEntity.ok(response);
    }

    // AUTHENTICATED: get ride offer by id
    @GetMapping("/{id}")
    public ResponseEntity<RideOfferResponse> getRideOfferById(@PathVariable Long id) {
        RideOfferResponse response = rideOfferService.getRideOfferById(id);
        return ResponseEntity.ok(response);
    }

    // DRIVER: get all ride offers for a driver
    @GetMapping("/driver/{driverId}")
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<List<RideOfferResponse>> getRideOffersByDriver(@PathVariable Long driverId) {
        List<RideOfferResponse> responses = rideOfferService.getRideOffersByDriver(driverId);
        return ResponseEntity.ok(responses);
    }

    // AUTHENTICATED (or open): search rides by origin, destination, date
    @GetMapping("/search")
    public ResponseEntity<List<RideOfferResponse>> searchRideOffers(
            @RequestParam String origin,
            @RequestParam String destination,
            @RequestParam String travelDate) {

        List<RideOfferResponse> responses = rideOfferService.searchRideOffers(origin, destination, travelDate);
        return ResponseEntity.ok(responses);
    }
}
