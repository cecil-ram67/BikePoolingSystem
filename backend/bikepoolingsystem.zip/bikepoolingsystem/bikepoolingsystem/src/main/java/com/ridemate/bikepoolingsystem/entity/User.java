package com.ridemate.bikepoolingsystem.entity;

import com.ridemate.bikepoolingsystem.entity.FileUpload;

import com.ridemate.bikepoolingsystem.enumtype.Role;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String fullName;

    @Column(nullable = false, unique = true, length = 150)
    private String email;

    @Column(nullable = false, length = 100)
    private String password; // hashed

    @Column(length = 20)
    private String phoneNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Role role;
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "license_file_id")
    private FileUpload licenseFile;

    @Column(nullable = false)
    private Boolean licenseUploaded = false;


    @Column(nullable = false)
    private Boolean isDeleted = false;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    public void onCreate() {
        LocalDateTime now = LocalDateTime.now();
        this.createdAt = now;
        this.updatedAt = now;
        if (isDeleted == null) {
            isDeleted = false;
        }
        if (licenseUploaded == null) {
            licenseUploaded = false;
        }
    }


    @PreUpdate
    public void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
