package com.ridemate.bikepoolingsystem.dto;

import java.time.Instant;

public record HealthResponse(
        String status,
        Instant timestamp,
        String service
) {
}
