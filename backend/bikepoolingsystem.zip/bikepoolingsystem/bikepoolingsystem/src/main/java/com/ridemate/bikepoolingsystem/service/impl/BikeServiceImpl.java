package com.ridemate.bikepoolingsystem.service.impl;

import com.ridemate.bikepoolingsystem.dto.bike.BikeCreateRequest;
import com.ridemate.bikepoolingsystem.dto.bike.BikeResponse;
import com.ridemate.bikepoolingsystem.dto.bike.BikeUpdateRequest;
import com.ridemate.bikepoolingsystem.entity.Bike;
import com.ridemate.bikepoolingsystem.entity.User;
import com.ridemate.bikepoolingsystem.enumtype.Role;
import com.ridemate.bikepoolingsystem.exception.BadRequestException;
import com.ridemate.bikepoolingsystem.exception.ResourceNotFoundException;
import com.ridemate.bikepoolingsystem.repository.BikeRepository;
import com.ridemate.bikepoolingsystem.repository.UserRepository;
import com.ridemate.bikepoolingsystem.service.BikeService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BikeServiceImpl implements BikeService {

    private final BikeRepository bikeRepository;
    private final UserRepository userRepository;

    public BikeServiceImpl(BikeRepository bikeRepository, UserRepository userRepository) {
        this.bikeRepository = bikeRepository;
        this.userRepository = userRepository;
    }

    @Override
    public BikeResponse createBike(BikeCreateRequest request) {
        // validate driver
        User driver = userRepository.findByIdAndIsDeletedFalse(request.driverId())
                .orElseThrow(() ->
                        new ResourceNotFoundException("Driver not found with id: " + request.driverId()));

        if (driver.getRole() != Role.DRIVER) {
            throw new BadRequestException("User with id " + driver.getId() + " is not a DRIVER");
        }

        // unique registration number
        if (bikeRepository.existsByRegistrationNumberAndIsDeletedFalse(request.registrationNumber())) {
            throw new BadRequestException("Bike with this registration number already exists");
        }

        if (request.maxSeats() < 1 || request.maxSeats() > 2) {
            throw new BadRequestException("Max seats must be between 1 and 2");
        }

        Bike bike = Bike.builder()
                .driver(driver)
                .brand(request.brand())
                .model(request.model())
                .registrationNumber(request.registrationNumber())
                .maxSeats(request.maxSeats())
                .isActive(true)
                .isDeleted(false)
                .build();

        Bike saved = bikeRepository.save(bike);
        return toResponse(saved);
    }

    @Override
    public BikeResponse updateBike(Long bikeId, BikeUpdateRequest request) {
        Bike bike = bikeRepository.findByIdAndIsDeletedFalse(bikeId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Bike not found with id: " + bikeId));

        bike.setBrand(request.brand());
        bike.setModel(request.model());

        if (request.registrationNumber() != null &&
                !request.registrationNumber().isBlank() &&
                !request.registrationNumber().equals(bike.getRegistrationNumber())) {

            if (bikeRepository.existsByRegistrationNumberAndIsDeletedFalse(request.registrationNumber())) {
                throw new BadRequestException("Bike with this registration number already exists");
            }
            bike.setRegistrationNumber(request.registrationNumber());
        }

        if (request.maxSeats() != null) {
            if (request.maxSeats() < 1 || request.maxSeats() > 2) {
                throw new BadRequestException("Max seats must be between 1 and 2");
            }
            bike.setMaxSeats(request.maxSeats());
        }

        if (request.isActive() != null) {
            bike.setIsActive(request.isActive());
        }

        Bike updated = bikeRepository.save(bike);
        return toResponse(updated);
    }

    @Override
    public BikeResponse getBikeById(Long bikeId) {
        Bike bike = bikeRepository.findByIdAndIsDeletedFalse(bikeId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Bike not found with id: " + bikeId));
        return toResponse(bike);
    }

    @Override
    public List<BikeResponse> getBikesByDriver(Long driverId) {
        List<Bike> bikes = bikeRepository.findAllByDriverIdAndIsDeletedFalse(driverId);
        return bikes.stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    public void softDeleteBike(Long bikeId) {
        Bike bike = bikeRepository.findByIdAndIsDeletedFalse(bikeId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Bike not found with id: " + bikeId));
        bike.setIsDeleted(true);
        bikeRepository.save(bike);
    }

    private BikeResponse toResponse(Bike bike) {
        return new BikeResponse(
                bike.getId(),
                bike.getDriver().getId(),
                bike.getDriver().getFullName(),
                bike.getBrand(),
                bike.getModel(),
                bike.getRegistrationNumber(),
                bike.getMaxSeats(),
                bike.getIsActive(),
                bike.getCreatedAt(),
                bike.getUpdatedAt()
        );
    }
}
