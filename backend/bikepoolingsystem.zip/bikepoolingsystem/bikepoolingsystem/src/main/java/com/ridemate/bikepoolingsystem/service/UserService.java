package com.ridemate.bikepoolingsystem.service;

import com.ridemate.bikepoolingsystem.dto.user.UserDto;

import java.util.List;

public interface UserService {

    UserDto getUserById(Long id);

    List<UserDto> getAllUsers();

    void softDeleteUser(Long id);
}
