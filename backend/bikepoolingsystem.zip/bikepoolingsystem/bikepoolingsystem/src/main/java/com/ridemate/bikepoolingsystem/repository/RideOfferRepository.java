package com.ridemate.bikepoolingsystem.repository;

import com.ridemate.bikepoolingsystem.entity.RideOffer;
import com.ridemate.bikepoolingsystem.enumtype.RideStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface RideOfferRepository extends JpaRepository<RideOffer, Long> {

    Optional<RideOffer> findByIdAndIsDeletedFalse(Long id);

    List<RideOffer> findAllByDriverIdAndIsDeletedFalse(Long driverId);

    List<RideOffer> findByOriginIgnoreCaseAndDestinationIgnoreCaseAndTravelDateAndIsDeletedFalseAndStatus(
            String origin,
            String destination,
            LocalDate travelDate,
            RideStatus status
    );

    @Query("""
    SELECT r FROM RideOffer r 
    WHERE 
        LOWER(r.origin) = LOWER(:origin) AND 
        LOWER(r.destination) = LOWER(:destination) AND 
        r.travelDate = :travelDate AND 
        r.status = 'OPEN'
""")
    List<RideOffer> searchRideOffers(String origin, String destination, String travelDate);

}
